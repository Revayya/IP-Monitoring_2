CREATE DATABASE IF NOT EXISTS `ip_monitoring_system`;
USE `ip_monitoring_system`;

CREATE TABLE `settings` (
  `setting_key` varchar(50) NOT NULL,
  `setting_value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES
('ping_interval', '60'),
('timeout', '1000'),
('retry_count', '3'),
('offline_threshold', '3'),
('max_devices_per_cycle', '50'),
('monitoring_enabled', '0'),
('log_retention_days', '30');

CREATE TABLE `devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `ip_address` varchar(50) NOT NULL,
  `status` enum('ONLINE','OFFLINE','UNKNOWN') DEFAULT 'UNKNOWN',
  `last_checked` datetime DEFAULT NULL,
  `last_response_time` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `ping_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) NOT NULL,
  `status` enum('ONLINE','OFFLINE','TIMEOUT','ERROR') NOT NULL,
  `response_time` int(11) DEFAULT NULL,
  `ping_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `device_id` (`device_id`),
  CONSTRAINT `fk_device` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
