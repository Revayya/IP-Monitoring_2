<!--#include virtual="/IPMonitoring/includes/db.asp"-->
<!--#include virtual="/IPMonitoring/includes/json.asp"-->
<!--#include virtual="/IPMonitoring/includes/functions.asp"-->
<!--#include virtual="/IPMonitoring/includes/ping.asp"-->
<%
Response.ContentType = "application/json"
Response.Expires = -1

' We'll simulate receiving a JSON payload and parsing device_id.
' Since Classic ASP doesn't have native JSON parsing, we'll do a simple regex or string manipulation.
Dim postData, deviceId, regEx, matches
postData = GetPostData()

Set regEx = New RegExp
regEx.Pattern = """device_id""\s*:\s*(\d+)"
regEx.IgnoreCase = True

deviceId = ""
If regEx.Test(postData) Then
    Set matches = regEx.Execute(postData)
    deviceId = matches(0).SubMatches(0)
End If

If deviceId = "" Then
    Response.Write("{""success"": false, ""message"": ""Missing device ID""}")
    Response.End
End If

Call OpenDB()

' Get IP
Dim rs, ipAddress
Set rs = Server.CreateObject("ADODB.Recordset")
rs.Open "SELECT ip_address FROM devices WHERE id = " & SanitizeInput(deviceId), objConn
If rs.EOF Then
    rs.Close
    Call CloseDB()
    Response.Write("{""success"": false, ""message"": ""Device not found""}")
    Response.End
End If

ipAddress = rs("ip_address")
rs.Close

If Not IsValidIP(ipAddress) Then
    Call CloseDB()
    Response.Write("{""success"": false, ""message"": ""Invalid IP Address""}")
    Response.End
End If

' Ping
Dim respTime, statusStr
Call PingIP(ipAddress, respTime, statusStr)

' Insert log
Dim cmd, curTime
curTime = Year(Now()) & "-" & Right("0" & Month(Now()), 2) & "-" & Right("0" & Day(Now()), 2) & " " & Right("0" & Hour(Now()), 2) & ":" & Right("0" & Minute(Now()), 2) & ":" & Right("0" & Second(Now()), 2)

Set cmd = Server.CreateObject("ADODB.Command")
cmd.ActiveConnection = objConn
cmd.CommandText = "INSERT INTO ping_logs (device_id, status, response_time, ping_time) VALUES (?, ?, ?, ?)"

cmd.Parameters.Append cmd.CreateParameter("@device_id", 3, 1, , CInt(deviceId))
cmd.Parameters.Append cmd.CreateParameter("@status", 200, 1, 20, statusStr)
If IsNull(respTime) Then
    cmd.Parameters.Append cmd.CreateParameter("@resp", 3, 1, , Null)
Else
    cmd.Parameters.Append cmd.CreateParameter("@resp", 3, 1, , CInt(respTime))
End If
cmd.Parameters.Append cmd.CreateParameter("@time", 200, 1, 20, curTime)

cmd.Execute

' Update device
Set cmd = Server.CreateObject("ADODB.Command")
cmd.ActiveConnection = objConn
cmd.CommandText = "UPDATE devices SET status = ?, last_checked = ?, last_response_time = ? WHERE id = ?"
cmd.Parameters.Append cmd.CreateParameter("@status", 200, 1, 20, statusStr)
cmd.Parameters.Append cmd.CreateParameter("@last_checked", 200, 1, 20, curTime)
If IsNull(respTime) Then
    cmd.Parameters.Append cmd.CreateParameter("@resp", 3, 1, , Null)
Else
    cmd.Parameters.Append cmd.CreateParameter("@resp", 3, 1, , CInt(respTime))
End If
cmd.Parameters.Append cmd.CreateParameter("@id", 3, 1, , CInt(deviceId))

cmd.Execute

Call CloseDB()

' Build response
Dim jsonResp
jsonResp = "{"
jsonResp = jsonResp & """success"": true,"
jsonResp = jsonResp & """ip"": """ & EscapeJSONString(ipAddress) & ""","
jsonResp = jsonResp & """status"": """ & EscapeJSONString(statusStr) & ""","
If IsNull(respTime) Then
    jsonResp = jsonResp & """responseTime"": null,"
Else
    jsonResp = jsonResp & """responseTime"": " & respTime & ","
End If
jsonResp = jsonResp & """pingTime"": """ & EscapeJSONString(curTime) & """"
jsonResp = jsonResp & "}"

Response.Write(jsonResp)
%>
