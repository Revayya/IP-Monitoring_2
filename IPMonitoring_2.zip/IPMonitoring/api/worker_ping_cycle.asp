<!--#include virtual="/IPMonitoring/includes/db.asp"-->
<!--#include virtual="/IPMonitoring/includes/functions.asp"-->
<!--#include virtual="/IPMonitoring/includes/ping.asp"-->
<%
Server.ScriptTimeout = 3600 ' Long timeout for worker cycle

Call OpenDB()

' Check if enabled
Dim rsEnabled
Set rsEnabled = Server.CreateObject("ADODB.Recordset")
rsEnabled.Open "SELECT setting_value FROM settings WHERE setting_key = 'monitoring_enabled'", objConn
If rsEnabled.EOF Or rsEnabled("setting_value") <> "1" Then
    rsEnabled.Close
    Call CloseDB()
    Response.Write("Monitoring is disabled.")
    Response.End
End If
rsEnabled.Close

' Get devices to ping (could use a batch logic, for now select all active)
' For 150 devices, pinging in a loop might take 150 seconds if they all timeout. 
' A real production env might thread it, but Classic ASP is single threaded.
' The batch logic works fine within the 3600 timeout.

Dim rsDev
Set rsDev = Server.CreateObject("ADODB.Recordset")
rsDev.Open "SELECT id, ip_address FROM devices WHERE is_active = 1", objConn

Dim respTime, statusStr, cmd, curTime

Do While Not rsDev.EOF
    Call PingIP(rsDev("ip_address"), respTime, statusStr)
    
    curTime = Year(Now()) & "-" & Right("0" & Month(Now()), 2) & "-" & Right("0" & Day(Now()), 2) & " " & Right("0" & Hour(Now()), 2) & ":" & Right("0" & Minute(Now()), 2) & ":" & Right("0" & Second(Now()), 2)
    
    ' Update Log
    Set cmd = Server.CreateObject("ADODB.Command")
    cmd.ActiveConnection = objConn
    cmd.CommandText = "INSERT INTO ping_logs (device_id, status, response_time, ping_time) VALUES (?, ?, ?, ?)"
    cmd.Parameters.Append cmd.CreateParameter("@device_id", 3, 1, , CInt(rsDev("id")))
    cmd.Parameters.Append cmd.CreateParameter("@status", 200, 1, 20, statusStr)
    If IsNull(respTime) Then
        cmd.Parameters.Append cmd.CreateParameter("@resp", 3, 1, , Null)
    Else
        cmd.Parameters.Append cmd.CreateParameter("@resp", 3, 1, , CInt(respTime))
    End If
    cmd.Parameters.Append cmd.CreateParameter("@time", 200, 1, 20, curTime)
    cmd.Execute
    
    ' Update device
    Set cmd = Server.CreateObject("ADODB.Command")
    cmd.ActiveConnection = objConn
    cmd.CommandText = "UPDATE devices SET status = ?, last_checked = ?, last_response_time = ? WHERE id = ?"
    cmd.Parameters.Append cmd.CreateParameter("@status", 200, 1, 20, statusStr)
    cmd.Parameters.Append cmd.CreateParameter("@last_checked", 200, 1, 20, curTime)
    If IsNull(respTime) Then
        cmd.Parameters.Append cmd.CreateParameter("@resp", 3, 1, , Null)
    Else
        cmd.Parameters.Append cmd.CreateParameter("@resp", 3, 1, , CInt(respTime))
    End If
    cmd.Parameters.Append cmd.CreateParameter("@id", 3, 1, , CInt(rsDev("id")))
    cmd.Execute
    
    rsDev.MoveNext
Loop
rsDev.Close

Call CloseDB()

Response.Write("Cycle complete.")
%>
