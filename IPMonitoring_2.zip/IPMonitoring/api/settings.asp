<!--#include virtual="/IPMonitoring/includes/db.asp"-->
<!--#include virtual="/IPMonitoring/includes/json.asp"-->
<%
Response.ContentType = "application/json"
Response.Expires = -1

Call OpenDB()

Dim rs, jsonStr, isFirst
Set rs = Server.CreateObject("ADODB.Recordset")
rs.Open "SELECT setting_key, setting_value FROM settings", objConn, 1, 1

jsonStr = "{""settings"": {"

isFirst = True
Do While Not rs.EOF
    If Not isFirst Then jsonStr = jsonStr & ","
    jsonStr = jsonStr & """" & EscapeJSONString(rs("setting_key")) & """: """ & EscapeJSONString(rs("setting_value")) & """"
    isFirst = False
    rs.MoveNext
Loop

rs.Close
Set rs = Nothing

jsonStr = jsonStr & "}}"
Response.Write(jsonStr)

Call CloseDB()
%>
