<!--#include virtual="/IPMonitoring/includes/db.asp"-->
<!--#include virtual="/IPMonitoring/includes/json.asp"-->
<%
Response.ContentType = "application/json"
Response.Expires = -1

Call OpenDB()

Dim rs, jsonStr, isFirst
Set rs = Server.CreateObject("ADODB.Recordset")

' Fetch the latest 200 logs to avoid overwhelming the browser
rs.Open "SELECT l.id, d.name, d.ip_address, l.status, l.response_time, l.ping_time FROM ping_logs l JOIN devices d ON l.device_id = d.id ORDER BY l.ping_time DESC LIMIT 200", objConn, 1, 1

jsonStr = "{""logs"": ["
isFirst = True

Do While Not rs.EOF
    If Not isFirst Then jsonStr = jsonStr & ","
    jsonStr = jsonStr & "{"
    jsonStr = jsonStr & """id"": " & rs("id") & ","
    jsonStr = jsonStr & """device_name"": """ & EscapeJSONString(rs("name")) & ""","
    jsonStr = jsonStr & """ip_address"": """ & EscapeJSONString(rs("ip_address")) & ""","
    jsonStr = jsonStr & """status"": """ & EscapeJSONString(rs("status")) & ""","
    
    If IsNull(rs("response_time")) Then
        jsonStr = jsonStr & """response_time"": null,"
    Else
        jsonStr = jsonStr & """response_time"": " & rs("response_time") & ","
    End If
    
    jsonStr = jsonStr & """ping_time"": """ & EscapeJSONString(rs("ping_time")) & """"
    jsonStr = jsonStr & "}"
    isFirst = False
    rs.MoveNext
Loop

rs.Close
Set rs = Nothing

jsonStr = jsonStr & "]}"
Response.Write(jsonStr)

Call CloseDB()
%>
