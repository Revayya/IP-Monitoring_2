<!--#include virtual="/IPMonitoring/includes/db.asp"-->
<!--#include virtual="/IPMonitoring/includes/json.asp"-->
<%
Response.ContentType = "application/json"
Response.Expires = -1

Call OpenDB()

Dim rs, jsonStr, isFirst
Set rs = Server.CreateObject("ADODB.Recordset")
rs.Open "SELECT id, name, ip_address, status, last_checked FROM devices WHERE is_active = 1", objConn, 1, 1

jsonStr = "{""devices"": ["
isFirst = True

Do While Not rs.EOF
    If Not isFirst Then jsonStr = jsonStr & ","
    jsonStr = jsonStr & "{"
    jsonStr = jsonStr & """id"": " & rs("id") & ","
    jsonStr = jsonStr & """name"": """ & EscapeJSONString(rs("name")) & ""","
    jsonStr = jsonStr & """ip_address"": """ & EscapeJSONString(rs("ip_address")) & ""","
    jsonStr = jsonStr & """status"": """ & EscapeJSONString(rs("status")) & ""","
    jsonStr = jsonStr & """last_checked"": """ & EscapeJSONString(rs("last_checked")) & """"
    jsonStr = jsonStr & "}"
    isFirst = False
    rs.MoveNext
Loop

rs.Close
Set rs = Nothing

jsonStr = jsonStr & "]}"
Response.Write(jsonStr)

Call CloseDB()
%>
