<!--#include file="config.asp"-->
<%
Dim objConn

Sub OpenDB()
    If IsObject(objConn) Then
        If objConn.State = 1 Then Exit Sub
    End If
    
    Set objConn = Server.CreateObject("ADODB.Connection")
    Dim connString
    connString = "Driver={" & DB_DRIVER & "};Server=" & DB_SERVER & ";Database=" & DB_NAME & ";User=" & DB_USER & ";Password=" & DB_PASS & ";Port=" & DB_PORT & ";Option=3;"
    
    On Error Resume Next
    objConn.Open connString
    If Err.Number <> 0 Then
        Response.Write("{""error"": ""Database connection failed""}")
        Response.End
    End If
    On Error GoTo 0
End Sub

Sub CloseDB()
    If IsObject(objConn) Then
        If objConn.State = 1 Then objConn.Close
        Set objConn = Nothing
    End If
End Sub
%>
