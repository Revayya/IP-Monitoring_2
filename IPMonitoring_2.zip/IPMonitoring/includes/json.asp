<%
' Very basic JSON encoder for Classic ASP
Function EscapeJSONString(str)
    If IsNull(str) Or IsEmpty(str) Then
        EscapeJSONString = ""
        Exit Function
    End If
    Dim res
    res = Replace(str, "\", "\\")
    res = Replace(res, """", "\""")
    res = Replace(res, vbCrLf, "\n")
    res = Replace(res, vbCr, "\n")
    res = Replace(res, vbLf, "\n")
    res = Replace(res, vbTab, "\t")
    EscapeJSONString = res
End Function
%>
