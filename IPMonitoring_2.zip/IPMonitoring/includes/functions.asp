<%
' Utility Functions

Function IsValidIP(ipStr)
    Dim parts, i
    IsValidIP = False
    parts = Split(ipStr, ".")
    If UBound(parts) = 3 Then
        For i = 0 To 3
            If Not IsNumeric(parts(i)) Then Exit Function
            If CInt(parts(i)) < 0 Or CInt(parts(i)) > 255 Then Exit Function
        Next
        IsValidIP = True
    End If
End Function

Function SanitizeInput(str)
    If IsNull(str) Then
        SanitizeInput = ""
    Else
        SanitizeInput = Replace(str, "'", "''")
    End If
End Function

Function GetPostData()
    Dim byteCount, binRead
    byteCount = Request.TotalBytes
    If byteCount > 0 Then
        binRead = Request.BinaryRead(byteCount)
        GetPostData = BytesToStr(binRead)
    Else
        GetPostData = ""
    End If
End Function

Function BytesToStr(bytes)
    Dim stream
    Set stream = Server.CreateObject("ADODB.Stream")
    stream.Type = 1 ' adTypeBinary
    stream.Open()
    stream.Write(bytes)
    stream.Position = 0
    stream.Type = 2 ' adTypeText
    stream.Charset = "utf-8"
    BytesToStr = stream.ReadText()
    stream.Close()
    Set stream = Nothing
End Function
%>
