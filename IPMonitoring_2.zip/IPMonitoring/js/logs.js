// logs.js

async function loadLogs() {
    // Show a loading message
    const tbody = document.getElementById('logs-body');
    tbody.innerHTML = '<tr><td colspan="5">Loading logs...</td></tr>';
    
    const data = await fetchAPI('/logs.asp');
    
    if (data && data.logs) {
        tbody.innerHTML = '';
        
        if (data.logs.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5">No ping logs recorded yet.</td></tr>';
            return;
        }
        
        data.logs.forEach(log => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${log.device_name}</td>
                <td>${log.ip_address}</td>
                <td><span class="status-badge ${log.status.toLowerCase()}">${log.status}</span></td>
                <td>${log.response_time !== null ? log.response_time + ' ms' : '-'}</td>
                <td>${log.ping_time}</td>
            `;
            tbody.appendChild(tr);
        });
    } else {
        tbody.innerHTML = '<tr><td colspan="5" class="text-danger">Error loading logs.</td></tr>';
    }
}
