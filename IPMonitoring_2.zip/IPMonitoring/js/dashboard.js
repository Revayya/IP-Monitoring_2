// dashboard.js - Dashboard polling and updates

let dashboardInterval;

async function updateDashboard() {
    const data = await fetchAPI('/dashboard.asp');
    if (data && !data.error) {
        document.getElementById('stat-total').innerText = data.total_devices;
        document.getElementById('stat-online').innerText = data.online_devices;
        document.getElementById('stat-offline').innerText = data.offline_devices;
        document.getElementById('stat-avg-time').innerText = data.avg_response_time + ' ms';
        
        // Update monitoring status
        const statusInd = document.getElementById('monitoring-status-indicator');
        const btnStart = document.getElementById('btn-start-monitoring');
        const btnStop = document.getElementById('btn-stop-monitoring');
        
        if (data.monitoring_active) {
            statusInd.innerText = 'MONITORING ACTIVE';
            statusInd.className = 'status-badge online';
            btnStart.style.display = 'none';
            btnStop.style.display = 'inline-block';
        } else {
            statusInd.innerText = 'STOPPED';
            statusInd.className = 'status-badge offline';
            btnStart.style.display = 'inline-block';
            btnStop.style.display = 'none';
        }
        
        // Update latest events table
        // (Assuming data.latest_events is an array)
        if (data.latest_events) {
            const tbody = document.getElementById('latest-events-body');
            tbody.innerHTML = '';
            data.latest_events.forEach(event => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${event.device_name}</td>
                    <td>${event.ip_address}</td>
                    <td><span class="status-badge ${event.status.toLowerCase()}">${event.status}</span></td>
                    <td>${event.response_time !== null ? event.response_time + ' ms' : '-'}</td>
                    <td>${event.ping_time}</td>
                `;
                tbody.appendChild(tr);
            });
        }
    }
}

async function startMonitoring() {
    const res = await fetchAPI('/monitoring_start.asp', 'POST', {});
    if (res.success) {
        updateDashboard();
    } else {
        alert('Failed to start monitoring');
    }
}

async function stopMonitoring() {
    const res = await fetchAPI('/monitoring_stop.asp', 'POST', {});
    if (res.success) {
        updateDashboard();
    } else {
        alert('Failed to stop monitoring');
    }
}

// Start polling every 5 seconds
dashboardInterval = setInterval(updateDashboard, 5000);
// Initial fetch
updateDashboard();
