<!--#include virtual="/IPMonitoring/includes/db.asp"-->
<%
Dim errorMsg
errorMsg = ""

If Request.ServerVariables("REQUEST_METHOD") = "POST" Then
    Dim user, pass
    user = Request.Form("username")
    pass = Request.Form("password")
    
    Call OpenDB()
    
    Dim cmd, rs
    Set cmd = Server.CreateObject("ADODB.Command")
    cmd.ActiveConnection = objConn
    cmd.CommandText = "SELECT id FROM admins WHERE username = ? AND password = ?"
    cmd.Parameters.Append cmd.CreateParameter("@user", 200, 1, 50, user)
    cmd.Parameters.Append cmd.CreateParameter("@pass", 200, 1, 255, pass)
    
    Set rs = cmd.Execute()
    
    If Not rs.EOF Then
        Session("loggedin") = True
        rs.Close
        Set rs = Nothing
        Set cmd = Nothing
        Call CloseDB()
        Response.Redirect "index.asp"
    Else
        errorMsg = "Invalid username or password."
    End If
    
    If rs.State = 1 Then rs.Close
    Set rs = Nothing
    Set cmd = Nothing
    Call CloseDB()
End If
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - IP Monitoring</title>
    <style>
        * { box-sizing: border-box; }
        body { 
            font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); 
            display: flex; justify-content: center; align-items: center; 
            height: 100vh; margin: 0; 
        }
        .login-box { 
            background: white; 
            padding: 40px; 
            border-radius: 16px; 
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5), 0 10px 10px -5px rgba(0, 0, 0, 0.2); 
            width: 100%; max-width: 420px; 
            text-align: center; 
        }
        .login-box h2 { margin-bottom: 30px; color: #0f172a; font-weight: 800; font-size: 26px; }
        .form-group { margin-bottom: 20px; text-align: left; }
        .form-group label { display: block; margin-bottom: 8px; color: #475569; font-weight: 600; font-size: 14px;}
        .form-control { 
            width: 100%; padding: 12px 16px; border: 1px solid #cbd5e1; 
            border-radius: 8px; font-size: 15px; transition: all 0.2s ease;
            outline: none; background-color: #f8fafc;
        }
        .form-control:focus { border-color: #4361ee; background-color: white; box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.15); }
        .btn { 
            width: 100%; padding: 14px; background-color: #4361ee; 
            color: white; border: none; border-radius: 8px; 
            font-weight: 700; font-size: 16px; cursor: pointer; 
            transition: all 0.2s ease; box-shadow: 0 4px 10px rgba(67, 97, 238, 0.3);
        }
        .btn:hover { background-color: #3a0ca3; transform: translateY(-1px); }
        .error { background-color: #fee2e2; color: #991b1b; padding: 12px; border-radius: 8px; border: 1px solid #ef4444; margin-bottom: 20px; font-size: 14px; font-weight: 500;}
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <div class="login-box">
        <h2>Admin Login</h2>
        <% If errorMsg <> "" Then %>
            <div class="error"><%= errorMsg %></div>
        <% End If %>
        <form method="POST" action="login.asp">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control" required autofocus>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn">Login</button>
        </form>
    </div>
</body>
</html>
